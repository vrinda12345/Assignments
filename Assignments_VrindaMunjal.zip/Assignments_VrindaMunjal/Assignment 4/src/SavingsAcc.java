public class SavingsAcc extends Account {	
	final static double minBalance = 200;

	SavingsAcc(Person p, double balance) {
		super(p, balance);
	}	
	@Override
	void withdraw(double amount) {
		double balance = this.getBalance() - amount;
		if(balance >= minBalance) {
			this.setBalance(balance);
		}
		else {
			System.out.println("You should keep a min balance of" + minBalance);
		}
	}
}