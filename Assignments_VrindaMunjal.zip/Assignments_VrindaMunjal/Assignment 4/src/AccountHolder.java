public class AccountHolder {
	public static void main(String[] args) {
		Person smith = new Person();
		smith.setName("Smith");
		smith.setAge(20);

		Person kathy = new Person();
		kathy.setName("kathy");
		kathy.setAge(21);

		Account smAcc  = new SavingsAcc(smith, 2000);
		Account kyAcc  = new CurrentAcc(kathy, 3000, 6000);

		smAcc.deposit(2000);
		kyAcc.withdraw(2000);

		System.out.println(smAcc.getAccNum() + " " + smAcc.getAccHolder().getName() + "-" + smAcc.getBalance());
		System.out.println(kyAcc.getAccNum() + " " + kyAcc.getAccHolder().getName() + "-" + kyAcc.getBalance());		
	}
}