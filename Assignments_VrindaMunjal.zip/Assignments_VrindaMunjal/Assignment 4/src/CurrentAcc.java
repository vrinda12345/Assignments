public class CurrentAcc extends Account {
	private double overDraftLimit;

	CurrentAcc(Person p, double balance, double overDraftLimit) {
		super(p, balance);
		this.overDraftLimit = overDraftLimit;
	}	
	@Override
	void withdraw(double amount) {
		double balance = (this.getBalance() + overDraftLimit) - amount;
		if(balance > 0) {
			this.setBalance(balance);
		}
		else {
			System.out.println("overdraft limit exceed");
		}
	}
}