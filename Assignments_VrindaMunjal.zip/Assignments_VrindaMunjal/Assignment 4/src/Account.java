public class Account {
	private long accNum;
	private double balance;
	private Person accHolder;	

	Account(){}	
	Account(Person p, double balance)  {
		this.setAccHolder(p);
		this.setBalance(balance);
		this.setAccNum((long)(1000000 + Math.random()* 10000000));
	}	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}	
	void deposit(double amount) {
		this.setBalance(this.getBalance() + amount);
	}	
	void withdraw(double amount) {
		this.setBalance(this.getBalance() - amount);
	}
}