import java.util.*;	
public class Lab7_2 {
	public static void alternate(String s1,String s2){
		StringBuilder result = new StringBuilder();
		for(int i=0; i<s1.length(); i++){
			char ch = s1.charAt(i);
			result.append((i%2 != 0) ? ch : s2);
		}
		System.out.println(s1);
	}
	public static void main(String[] args) {
		String s1="FrankCastle";
		String s2="Sr";
		System.out.println("This is the scenario, choices aren't brief I admit. Please go through them carefully.");
		System.out.println("Enter your choice:");
		System.out.println("1. Character in each alternate index of S1 should be replaced with S2:");
		System.out.println("If S2 appears more than once in S1, replace the last occurrence of S2 in S1 with the reverse of S2,else return S1+S2");
		System.out.println("If S2 appears more than once in S1, delete the first occurrence of S2 in S1, else return S1");
		System.out.println("Divide S2 into two halves and add the first half to the beginning of the S1 and second half to the end of S1.");
		System.out.println("If S1 contains characters that is in S2 change all such characters to *");
		Scanner sc=new Scanner(System.in);
		int ch=sc.nextInt();
		switch(ch)	{
		case 1:
			alternate(s1,s2);
			break;
		}					
	}
}