import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class Lab7_1 {
	public int getSorted(int a[]){
		ArrayList<Integer> newArray = new ArrayList<Integer>();
		int reverse = 0;
		Arrays.sort(a);
		int n=0;
		for(int i=0;i<a.length;i++){
			n=a[i];
			while(n>0){
				int digit = n%10;
				reverse = reverse * 10 + digit;
				n=n/10;
			}
			newArray.add(reverse);
			reverse=0;
			n=0;
		}
		System.out.println(newArray);
		return 0;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Lab7_1 obj = new Lab7_1();
		System.out.println("Enter the number of elements:");
		int num = sc.nextInt();
		int a[]=new int[num];
		for(int i=0;i<num;i++){
			a[i]=sc.nextInt();
		}
		obj.getSorted(a);
	}
}