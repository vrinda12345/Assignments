import java.util.ArrayList;
import java.util.List;
public class Lab7_3 {
	public void removeElements(){
		List<String> list1 = new ArrayList<>();
		list1.add("Vrinda");
		list1.add("Sukh");
		list1.add("Gagan");
		list1.add("Akshay");
		list1.add("Aashi");
		list1.add("Manmeet");
		list1.add("Sagar");

		System.out.println(" List1 Elements: " + list1);

		List<String> list2 = new ArrayList<>();
		list2.add("Sagar");
		list2.add("Vrinda");
		list2.add("Manmeet");

		System.out.println(" List2 Elements: " + list2);
		list1.removeAll(list2);
		System.out.println("After removeAll list2 elements): " + list1);

		list1.clear();
		System.out.println("After clear(): " + list1);
	}
	public static void main(String[] args) {
		Lab7_3 obj=new Lab7_3();
		obj.removeElements();
	}
}