public class FileProgram {
	public static void main(String[] args) throws InterruptedException {

		String sourceFile = "D:\\source.txt";
		String targetFile = "D:\\target.txt";

		CopyDataThread copyThread = new CopyDataThread(sourceFile, targetFile);

		Thread copy = new Thread(copyThread);
		copy.start();
		copy.join();
	}
}