	public abstract class Expression11_1 implements ExpInterface11_1{
		public static void main(String[] args) {
			        ExpInterface11_1 fobj = (double x,double y)->System.out.println(x+" power of "+y+" = "+Math.pow(x, y)); 
			        fobj.abstractFunc(5,6); 
		}
	}