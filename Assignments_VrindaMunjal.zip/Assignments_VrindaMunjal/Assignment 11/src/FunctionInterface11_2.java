public interface FunctionInterface11_2 {
	String space(String x);
	}