import java.util.function.BiFunction;
public class MainClass11_4 {  
public static void main(String[] args) {  
BiFunction<Integer, Integer, Integer>adder = Arithmetics11_4::add;  
int result = adder.apply(10, 20);  
System.out.println(result);  
}  
}  