public class Person2_3 {	
	private String firstName;
	private String lastName;
	private char gender;
	private String phoneNo;
	Person2_3() {
		firstName = "";
		lastName = "";
		gender = 'N';
		phoneNo = "";
	}
	Person2_3(String fn, String ln, char gen) {
		setFirstName(fn);
		setlastName(ln);
		setGender(gen);
	}
	void setFirstName(String fn) {
		firstName = fn;
	}

	void setlastName(String ln) {
		lastName = ln;
	}

	void setGender(char gen) {
		gender = gen;
	}

	void setPhoneNo(String pn) {
		phoneNo = pn;
	}
	String getFirstName() {
		return firstName;
	}

	String getlastName() {
		return lastName;
	}
	char getGender() {
		return gender;
	}
	String getPhoneNo() {
		return phoneNo;
	}		
	void personDetails() {
		System.out.println("Person Details..........");
		System.out.println();
		System.out.println("First Name: " + getFirstName());
		System.out.println("Last Name: " + getlastName());
		System.out.println("Gender: " + getGender());
		System.out.println("phone number: " + getPhoneNo());

	}
}