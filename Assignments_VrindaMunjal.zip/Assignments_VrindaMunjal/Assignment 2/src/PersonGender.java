public class PersonGender { 
	private String firstName;
	private String lastName;
	private Gender gender;
	private String phoneNo;

	PersonGender() {
		firstName = "";
		lastName = "";
		gender = Gender.O;
		phoneNo = "";
	}
	PersonGender(String fn, String ln, Gender gen) {
		setFirstName(fn);
		setlastName(ln);
		setGender(gen);
	}
	void setFirstName(String fn) {
		firstName = fn;
	}
	void setlastName(String ln) {
		lastName = ln;
	}
	void setGender(Gender gen) {
		gender = gen;
	}	
	void setPhoneNo(String pn) {
		phoneNo = pn;
	}
	String getFirstName() {
		return firstName;
	}
	String getlastName() {
		return lastName;
	}	
	Gender getGender() {
		return gender;
	}
	String getPhoneNo() {
		return phoneNo;
	}
	void personDetails() {
		System.out.println("Person Details..........");
		System.out.println();
		System.out.println("First Name: " + getFirstName());
		System.out.println("Last Name: " + getlastName());
		System.out.println("Gender: " + getGender());
		System.out.println("phone number: " + getPhoneNo());	
	}
}