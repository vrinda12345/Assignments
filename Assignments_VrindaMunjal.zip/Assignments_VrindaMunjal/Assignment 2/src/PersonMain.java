public class PersonMain {
	public static void main(String[] args) {
		Person2_3 vrinda = new Person2_3("Vrinda", "Munjal", 'F');
		vrinda.setPhoneNo("8168085640");
		vrinda.personDetails();
	}
}