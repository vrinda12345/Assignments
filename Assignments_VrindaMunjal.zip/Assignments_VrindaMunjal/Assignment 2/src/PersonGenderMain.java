import java.util.Scanner;

public class PersonGenderMain {
	public static void main(String[] args) {		
		Gender gen;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Gender");
		int offset = sc.nextInt();
		switch(offset) {
		case 1:
			gen = Gender.M;
			break;
		case 2:
			gen = Gender.F;
			break;
		default:
			gen = Gender.O;
		}
		PersonGender vrinda = new PersonGender("Vrinda", "Munjal", gen);
		vrinda.setPhoneNo("9056548627");
		vrinda.personDetails();
		sc.close();
	}
}