public class CmdArg2_2 {

	public static void main(String[] args) {
		if(args.length == 1) {
			int num = Integer.parseInt(args[0]);

			String sign = (num >= 0) ? "Positive" : "Negative";
			System.out.println(sign);	
		}
	}
}