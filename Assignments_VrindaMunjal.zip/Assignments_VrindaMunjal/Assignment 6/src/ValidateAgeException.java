public class ValidateAgeException extends Exception{
	public ValidateAgeException() {
		super();
	}
	public ValidateAgeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public ValidateAgeException(String message, Throwable cause) {
		super(message, cause);
	}
	public ValidateAgeException(String message) {
		super(message);
	}
	public ValidateAgeException(Throwable cause) {
		super(cause);
	}
}