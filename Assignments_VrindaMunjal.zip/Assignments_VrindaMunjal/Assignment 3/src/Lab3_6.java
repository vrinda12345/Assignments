import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Scanner;
public class Lab3_6 {
public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the time zone from the following"
			+"\n America/NewYork,\n Europe/London,\n US/Pacific,"
			+ "\n Asia/Tokyo,\n Africa/Cairo,\n Australia/Sydney");
	
	String zone_id=sc.next();
	LocalDateTime dateTime=java.time.LocalDateTime.now(ZoneId.of(zone_id));
	System.out.println("The Local Date and Time of "+zone_id +"Zone is "+dateTime);
}
}
