import java.util.Scanner;
public class Lab3_7 {
	public boolean ValidateUserId(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter User Id:");

		String userId=sc.next();
		int a=userId.indexOf('_')+1;

		if(a>=8 && userId.endsWith("job")){
			System.out.println("Valid");
		}
		else{
			System.out.println("InValid");
			return false;
		}
		return true;	
	}
	public static void main(String args[]){
		Lab3_7 obj=new Lab3_7();
		obj.ValidateUserId();
	}
}
