import java.time.LocalDate;
import java.time.Period;
public class Lab3_3 {
	public void durationDate(){
		LocalDate birthdate = LocalDate.of(1998, 04, 05);
		LocalDate currentdate = LocalDate.now();

		Period diff = Period.between(birthdate, currentdate);

		System.out.println(diff.getYears()+"years,"+ diff.getMonths()
				+ "months,and " + diff.getDays()+"days");
	}
public static void main(String args[]){
	Lab3_3 obj=new Lab3_3();
	obj.durationDate();
}	
}
