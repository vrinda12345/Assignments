import java.time.LocalDate;
import java.util.Scanner;
public class Lab3_5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter purchase date in dd-mm-yyyy format : ");
		String s1=sc.next();
		s1=s1+"";

		int day1=Integer.parseInt(s1.substring(0,2));
		int month1=Integer.parseInt(s1.substring(3,5));
		int year1=Integer.parseInt(s1.substring(6,10));

		LocalDate purchaseDate=LocalDate.of(year1, month1, year1);
		System.out.println(purchaseDate);
		System.out.println("enter warranty period:\nenter month:");

		long mm=sc.nextLong();
		System.out.println("enter year :");

		long yy=sc.nextLong();

		purchaseDate=purchaseDate.plusMonths(mm);
		purchaseDate=purchaseDate.plusYears(yy);
		System.out.println("Warranty expires on: "+purchaseDate);
	}
}
