import java.util.Scanner;
public class Lab3_2 {
	public boolean positiveString(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String:");
		String s1=sc.next();
		s1=s1.toUpperCase();
		boolean flag=true;
		for(int i=0;i<s1.length()-1;i++){
			if(s1.charAt(i)<=s1.charAt(i+1)){
				flag=true;
			}
			else {
				flag=false;
				break;
			}
		}
		if(flag == true){
			System.out.println("True");
			return true;
		}
		else{
			System.out.println("False");
			return false;
		}
	}
	public static void main(String args[]){
		Lab3_2 obj=new Lab3_2();
		obj.positiveString();
	}
}