import java.util.HashSet;
import java.util.Scanner;
public class Lab3_1 {
	Scanner sc=new Scanner(System.in);
	public void stringOperation() {
		System.out.println("Enter a String:");
		String s1=sc.nextLine();
		System.out.println("1.Add the String to itself:");
		System.out.println("2.Repalce odd positions with #:");
		System.out.println("3.Remove duplicate characters in the String:");
		System.out.println("4.Change odd characters to upper case:");
		System.out.println("Enter your choice:");

		int choice=sc.nextInt();
		switch(choice){		
		case 1: String s2= s1.concat(s1);
		System.out.println("String After Concatenation:"+s2);
		break;
		case 2: String s21="";
		for(int i=0;i<s1.length();i++){
			if (i%2!=0)
				s21+=s1.charAt(i);
			else
				s21+='#';
		}
		System.out.println(s21);
		break;		
		case 3:
			HashSet<Character> s3=new HashSet<Character>();
			for(int i=0;i<s1.length();i++){
				s3.add(s1.charAt(i));
			}
			System.out.println("String after removing Duplications"+s3);
			break;	    
		case 4: s1=s1.toLowerCase();
		for(int i=0;i<s1.length(); i++){
			if(i%2!=0){
				System.out.print(Character.toLowerCase(s1.charAt(i)));
			}
			else{
				System.out.print(Character.toUpperCase(s1.charAt(i)));
			}
		}	
		break;	    
		default: System.out.println("Invalid Choice");
		}
	}
	public static void main(String args[]){
		Lab3_1 obj1=new Lab3_1();
		obj1.stringOperation();
	}
}